import React from "react";
import classes from "./Content.module.css";

const Button = () => {
  return (
    <div className={classes.Indicator}>
      <h2>Type Text</h2>
      <p>
        Lorem Ipsum is simply dummy text of the printing and typesetting
        industry.
      </p>
    </div>
  );
};
export default Button;